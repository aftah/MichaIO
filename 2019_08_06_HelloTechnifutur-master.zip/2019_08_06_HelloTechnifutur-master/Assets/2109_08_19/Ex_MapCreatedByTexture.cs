﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ex_MapCreatedByTexture : MonoBehaviour
{
    public Texture2D  m_texture;
    public GameObject m_prefab;

    public void CreateMap() {

    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
