# 2019_08_06_HelloTechnifutur
Sharing example for Technifutur participant
